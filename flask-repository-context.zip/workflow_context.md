# flask — Context for AI

5 workflows · 0 risk findings · 403 verified connections · 482 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. Dispatch a WSGI request to a registered view and return a finalized response

Workflow ID: `business_path_9d727dd6ddfc1a26`

A WSGI server invokes the Flask application; Flask establishes request context, runs request preprocessing and route dispatch, finalizes the result, and returns it to the caller.

**Purpose:** Have an HTTP request processed by the configured Flask application

**Business outcome**

- Routes requests to the registered endpoint handler
- Provides a finalized response to the WSGI server for delivery

**Important behavior and rules**

- A view return value is converted into a response; None is rejected as an invalid response.
- After-request callbacks process the response in reverse registration order, and a non-null session is saved during response processing.
- If request preprocessing returns a non-None value, that value is used as the response and normal view dispatch stops.
- An automatic OPTIONS response is produced when the route enables automatic options and the request method is OPTIONS.

**Identified functions:** `Flask.wsgi_app(environ, start_response)`, `Flask.__call__(environ, start_response)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/flask/app.py` | `chunk_202df8247807557d` |
| Source section | `src/flask/app.py` | `chunk_208869a6ca0eb4ba` |
| Source section | `src/flask/app.py` | `chunk_4d856dffb2d1c0a3` |
| Source section | `src/flask/app.py` | `chunk_4de3e54cea769505` |
| Source section | `src/flask/app.py` | `chunk_8c4aa59e3a8b40bb` |
| Source section | `src/flask/app.py` | `chunk_a89de0d1a878d7fa` |
| Source section | `src/flask/app.py` | `chunk_ae04b44954f880ec` |

### 2. Serve a configured static file through the Flask application

Workflow ID: `business_path_d7e52ae58b311117`

The automatically registered static route invokes Flask.send_static_file, which serves a file from the configured static folder and returns the file response.

**Purpose:** Request a file made available by the application

**Business outcome**

- Provides configured static assets to callers as file responses

**Important behavior and rules**

- Static file serving requires a configured static folder.
- The file-serving operation uses the configured static folder and obtains its max-age from application configuration.
- If no static folder is configured, serving a static file raises RuntimeError.

**Identified functions:** `Automatically registered static route: <static_url_path>/<path:filename>`, `Flask.send_static_file(filename)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/flask/app.py` | `chunk_0afcbd92eb5174db` |
| Source section | `src/flask/app.py` | `chunk_6ad29564f7a08c8b` |

### 3. Register blueprint routes and setup callbacks on a Flask application.

Workflow ID: `business_path_1d3f024280de8981`

A Flask application registers a Blueprint, adds it to the application's registry, and applies deferred route and setup registrations.

**Purpose:** Make a Blueprint's routes and callbacks available through an application.

**Business outcome**

- Composes deferred blueprint routes and callbacks into an application.
- Registration makes the blueprint's routing configuration available to the application.

**Important behavior and rules**

- A computed blueprint registration name that is already present in the application registry is rejected.
- Blueprint setup methods are disallowed after the blueprint has been registered once.
- Registration raises ValueError if the computed blueprint name already exists in app.blueprints.
- Setup methods reject changes after the blueprint has been registered at least once.

**Identified functions:** `Blueprint.register(app, options) called by Flask.register_blueprint`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| BlueprintSetupState.add_url_rule | `src/flask/sansio/blueprints.py` | `chunk_3b20a473c486db47` |
| Source section | `src/flask/sansio/blueprints.py` | `chunk_8983f7abe21577fa` |
| Source section | `src/flask/sansio/blueprints.py` | `chunk_d9af4d179c6a6578` |

### 4. Load and update Flask application configuration

Workflow ID: `business_path_0cbc837362c53edd`

Configuration sources are read and selected values are assigned to the Flask application's configuration mapping.

**Purpose:** Configure application behavior from environment, files, or objects

**Business outcome**

- Application settings become available to the Flask application.

**Important behavior and rules**

- Config.from_mapping inserts only uppercase keys.
- Config.from_prefixed_env considers only environment variable names with the selected prefix and strips that prefix before assignment.
- from_mapping adds only keys for which key.isupper() is true.
- from_prefixed_env ignores environment names that do not start with the configured prefix.

**Identified functions:** `Config.from_prefixed_env`, `Config.from_file`, `Config.from_mapping`, `Config.from_pyfile`, `Config.from_envvar`, `Config.from_object`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/flask/config.py` | `chunk_2a15195d093a794b` |
| Source section | `src/flask/sansio/app.py` | `chunk_a14738da21cd15da` |
| Source section | `src/flask/sansio/app.py` | `chunk_b212dabf1ed675d9` |
| Source section | `src/flask/config.py` | `chunk_cd1ac4ab4dfc74dc` |

### 5. Maintain session data through signed cookies

Workflow ID: `business_path_0f86795dcce70f58`

During request context handling, Flask opens a session from the request cookie and saves, deletes, or leaves the cookie unchanged on the response according to session state and configuration.

**Purpose:** A request client carries session data across requests

**Business outcome**

- Session data can be read during request handling and represented in a response cookie when the save conditions apply.

**Important behavior and rules**

- The default session cookie is set when the session is modified, or when it is permanent and SESSION_REFRESH_EACH_REQUEST is enabled.
- An empty session is not written as a cookie; if it is modified, the existing cookie is deleted.
- Without a signing serializer, request context session access falls back to NullSession, whose mutation operations raise RuntimeError.
- If no signing serializer is available because the app has no secret key, open_session returns None; the context substitutes a NullSession.
- A nonempty session cookie is written only when should_set_cookie returns true; an empty modified session causes cookie deletion.

**Identified functions:** `AppContext.push`, `SecureCookieSessionInterface.save_session`, `SecureCookieSessionInterface.open_session`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| NullSession | `src/flask/sessions.py` | `chunk_0a407207be7ed794` |
| SessionInterface.should_set_cookie | `src/flask/sessions.py` | `chunk_277df63995874727` |
| SecureCookieSessionInterface.open_session | `src/flask/sessions.py` | `chunk_3c8a6bfae0776ce3` |
| Source section | `src/flask/ctx.py` | `chunk_a6940afbd6f42ea7` |
| SessionMixin.permanent | `src/flask/sessions.py` | `chunk_c6bd3a958ae29ccf` |
| SecureCookieSession.__init__ | `src/flask/sessions.py` | `chunk_ea6fb811df40af69` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_03327f5e7eb41467` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_0974fadcf02fc3bc`: imports_symbol; symbol: get_load_dotenv
- `chunk_03327f5e7eb41467` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_03327f5e7eb41467` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_2a11840d2c2debd8`: imports_symbol; symbol: Blueprint
- `chunk_05e5b226d8a8f906` → `chunk_2a11840d2c2debd8`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_dd100daace83e5ce`: imports_symbol; symbol: App
- `chunk_05e5b226d8a8f906` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_07bb9517c541cdb7` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_07bb9517c541cdb7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_39a4d795b4a8111a`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_e381cc4175c1d4ac`: imports_symbol; symbol: TaggedJSONSerializer
- `chunk_08e16ed6f5967458` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_092982a8e67b4df9` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_092982a8e67b4df9` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: DefaultJSONProvider
- `chunk_0b1a7e8eac1bdf86` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0dcaca236c8dd90b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0dcaca236c8dd90b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_0ea771d2dc963ea7` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_0ea771d2dc963ea7` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_0ea771d2dc963ea7` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_13b1a0f012773de6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_13b1a0f012773de6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_1cc6e0ef42852fa7` → `chunk_0bf0bfdb68912f6c`: imports_symbol; symbol: JSONTag
- `chunk_1cc6e0ef42852fa7` → `chunk_39a4d795b4a8111a`: file_import; symbol: not specified
- `chunk_1cc6e0ef42852fa7` → `chunk_e381cc4175c1d4ac`: imports_symbol; symbol: TaggedJSONSerializer
- `chunk_23539d2eaa639921` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_246c820854be1b6a` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_2a11840d2c2debd8` → `chunk_3b20a473c486db47`: imports_symbol; symbol: BlueprintSetupState
- `chunk_2a11840d2c2debd8` → `chunk_487841d24a31fccb`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_6088cc242bf9ab3f`: imports_symbol; symbol: AppGroup
- `chunk_2a11840d2c2debd8` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d9af4d179c6a6578`: imports_symbol; symbol: Blueprint
- `chunk_2a11840d2c2debd8` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_06d0425a273b91e9`: imports_symbol; symbol: after_this_request
- `chunk_2c1084f7c7016b47` → `chunk_079d522beff21bdb`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_2c1084f7c7016b47` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_2c1084f7c7016b47` → `chunk_29ffcfc402bbb372`: imports_symbol; symbol: send_file
- `chunk_2c1084f7c7016b47` → `chunk_2a11840d2c2debd8`: imports_symbol; symbol: Blueprint
- `chunk_2c1084f7c7016b47` → `chunk_2a11840d2c2debd8`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template_string
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template_string
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_34d76a0b6682f882`: imports_symbol; symbol: has_app_context
- `chunk_2c1084f7c7016b47` → `chunk_3575a2cecb320120`: imports_symbol; symbol: abort
- `chunk_2c1084f7c7016b47` → `chunk_36957f18a0a76b79`: imports_symbol; symbol: get_flashed_messages
- `chunk_2c1084f7c7016b47` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_2c1084f7c7016b47` → `chunk_6480eead4a4aa1ab`: imports_symbol; symbol: get_template_attribute
- `chunk_2c1084f7c7016b47` → `chunk_767441e328879929`: imports_symbol; symbol: stream_with_context
- `chunk_2c1084f7c7016b47` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_2c1084f7c7016b47` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_9cbcb5b6daffc5e3`: imports_symbol; symbol: copy_current_request_context
- `chunk_2c1084f7c7016b47` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_2c1084f7c7016b47` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_cd1ac4ab4dfc74dc`: imports_symbol; symbol: Config
- `chunk_2c1084f7c7016b47` → `chunk_d0db06956f7ea0fe`: imports_symbol; symbol: has_request_context
- `chunk_2c1084f7c7016b47` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_2c1084f7c7016b47` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_2c1084f7c7016b47` → `chunk_ead2aba9c8e43912`: imports_symbol; symbol: make_response
- `chunk_2c1084f7c7016b47` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_2c910577b76376cf` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_767441e328879929`: imports_symbol; symbol: stream_with_context
- `chunk_2c910577b76376cf` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_a6940afbd6f42ea7`: imports_symbol; symbol: AppContext
- `chunk_2c910577b76376cf` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_2c910577b76376cf` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_39cf700819890adc`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_c0eef923d4b41e30`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_340cdfcae1cb4b4d` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_340cdfcae1cb4b4d` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_364b2616c7c72f56` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_37874a17b33c977c` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: dumps
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: loads
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_39cf700819890adc` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_39cf700819890adc` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_39cf700819890adc` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_c0eef923d4b41e30`: imports_symbol; symbol: login_required
- `chunk_39cf700819890adc` → `chunk_c0eef923d4b41e30`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_39cf700819890adc` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_3a3a1d3005368514` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_3a3a1d3005368514` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_47e242225e1d303b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_0f14a6cec0376f18`: imports_symbol; symbol: _endpoint_from_view_func
- `chunk_487841d24a31fccb` → `chunk_53f0d53d1eb1f300`: imports_symbol; symbol: setupmethod
- `chunk_487841d24a31fccb` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_d633e0c444ff7754`: imports_symbol; symbol: Scaffold
- `chunk_487841d24a31fccb` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_4eca314f1a9aa408` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_4fbea67b4cf78839` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_4fbea67b4cf78839` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: init_db
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_612377321a46ae96` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_612377321a46ae96` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_642a47cdad401c03` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_642a47cdad401c03` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_646594ea66ce148b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_646594ea66ce148b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_6f518c88b8a0e44d` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_7c4eff8cf0cd72cc` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_7c4eff8cf0cd72cc` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_7c93120950e7c730` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_7e5fa90f1cd8ceed` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_1d759850fa45fce3`: imports_symbol; symbol: get_version
- `chunk_7eea0803ec01a0ea` → `chunk_222b449204f0f059`: imports_symbol; symbol: prepare_import
- `chunk_7eea0803ec01a0ea` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_7eea0803ec01a0ea` → `chunk_6088cc242bf9ab3f`: imports_symbol; symbol: AppGroup
- `chunk_7eea0803ec01a0ea` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_979f1ff9f1897a64`: imports_symbol; symbol: run_command
- `chunk_7eea0803ec01a0ea` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_b75110488e13ee01`: imports_symbol; symbol: load_dotenv
- `chunk_7eea0803ec01a0ea` → `chunk_b7b0f2b916869b76`: imports_symbol; symbol: FlaskGroup
- `chunk_7eea0803ec01a0ea` → `chunk_c342b07709d3ac6b`: imports_symbol; symbol: with_appcontext
- `chunk_7eea0803ec01a0ea` → `chunk_d97015c105003a3f`: imports_symbol; symbol: find_best_app
- `chunk_7eea0803ec01a0ea` → `chunk_dcab47d8a041180b`: imports_symbol; symbol: locate_app
- `chunk_7eea0803ec01a0ea` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_7eea0803ec01a0ea` → `chunk_ed3186b5dce1ee2f`: imports_symbol; symbol: NoAppException
- `chunk_8b04179a9854c150` → `chunk_42fa185a7e4af7e2`: file_import; symbol: not specified
- `chunk_8b04179a9854c150` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_8cce5ef592c7abc6` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_8eb1e0b497ed12a1` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_8eb1e0b497ed12a1` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_93794da8f1487f6e` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_93794da8f1487f6e` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: has_level_handler
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: wsgi_errors_stream
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_5204c53d5d715ef6`: imports_symbol; symbol: _split_blueprint_path
- `chunk_a793714a798140b5` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ac530dd929c76a21` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_ac530dd929c76a21` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_ad7e71b59e357b17` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_ad7e71b59e357b17` → `chunk_afda8edb08f57c20`: imports_symbol; symbol: main
- `chunk_ae04b44954f880ec` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_ae6ad21b2fc0258f` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_ae6ad21b2fc0258f` → `chunk_8cb0fead4a2cd549`: imports_module; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_8cb0fead4a2cd549`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_c6bd3a958ae29ccf`: imports_symbol; symbol: SessionMixin
- `chunk_ae6ad21b2fc0258f` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_aeaff9ba5c83618b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_aeaff9ba5c83618b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_b304ef07c4bd2603` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_b304ef07c4bd2603` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_b4748b8723c16f0b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_b4748b8723c16f0b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_b4748b8723c16f0b` → `chunk_ec18eff741183616`: imports_symbol; symbol: MethodView
- `chunk_b4748b8723c16f0b` → `chunk_ec18eff741183616`: imports_symbol; symbol: View
- `chunk_b6fd669f73039529` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_b6fd669f73039529` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: _default
- `chunk_bbf28cdf796b929b` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_c0eef923d4b41e30` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_c0eef923d4b41e30` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_c0eef923d4b41e30` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_c0eef923d4b41e30` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_c4e9fd0132a01851` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_c4e9fd0132a01851` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c4e9fd0132a01851` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_c4e9fd0132a01851` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_c4e9fd0132a01851` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_c89a6b5182f3b837` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_c8fa075adb35e66b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c8fa075adb35e66b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_ccdfaa0f380ec07a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_ce6f30f5c7c658b8` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_ce6f30f5c7c658b8` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_ce6f30f5c7c658b8` → `chunk_3c8a6bfae0776ce3`: imports_symbol; symbol: SecureCookieSessionInterface
- `chunk_ce6f30f5c7c658b8` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d18610b3e6441853` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d18610b3e6441853` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d1c7038e934a6ce8` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_344cc17acd65dd58`: imports_symbol; symbol: _CollectErrors
- `chunk_d2edbd1432944397` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_079d522beff21bdb`: imports_symbol; symbol: ConfigAttribute
- `chunk_d32aebe41ab61974` → `chunk_079d522beff21bdb`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_092f1c82779e9e8c`: imports_symbol; symbol: _AppCtxGlobals
- `chunk_d32aebe41ab61974` → `chunk_0f14a6cec0376f18`: imports_symbol; symbol: _endpoint_from_view_func
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: imports_symbol; symbol: DispatchingJinjaLoader
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: imports_symbol; symbol: Environment
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_487841d24a31fccb`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_d32aebe41ab61974` → `chunk_5204c53d5d715ef6`: imports_symbol; symbol: _split_blueprint_path
- `chunk_d32aebe41ab61974` → `chunk_53f0d53d1eb1f300`: imports_symbol; symbol: setupmethod
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: DefaultJSONProvider
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: JSONProvider
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_c3d38c601dbe09fe`: imports_symbol; symbol: find_package
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: create_logger
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_cd1ac4ab4dfc74dc`: imports_symbol; symbol: Config
- `chunk_d32aebe41ab61974` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_d633e0c444ff7754`: imports_symbol; symbol: Scaffold
- `chunk_d32aebe41ab61974` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_d506393e345117c1` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_d506393e345117c1` → `chunk_cbe68cbbc2b5ba76`: imports_symbol; symbol: EnvironBuilder
- `chunk_d506393e345117c1` → `chunk_ec73eaa6979995d4`: imports_symbol; symbol: FlaskCliRunner
- `chunk_d789d814bbcd589a` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d789d814bbcd589a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d89edffad1fc2099` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_d8ab3930496c9ba9` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_ded3aeb584246617` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_ded3aeb584246617` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_e0246e234c1bc17a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e0246e234c1bc17a` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_e0246e234c1bc17a` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_e58c6f98322254c7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e58c6f98322254c7` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_e65b72105426b434` → `chunk_2c910577b76376cf`: imports_symbol; symbol: _default_template_ctx_processor
- `chunk_e65b72105426b434` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_5e3caeea08dd525b`: imports_symbol; symbol: get_root_path
- `chunk_e65b72105426b434` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_e7009beab0a740e6` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_e7009beab0a740e6` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_e7009beab0a740e6` → `chunk_ec18eff741183616`: imports_symbol; symbol: View
- `chunk_ec18eff741183616` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_ec18eff741183616` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_ec18eff741183616` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ed378ed504c07fca` → `chunk_340cdfcae1cb4b4d`: file_import; symbol: not specified
- `chunk_f5aec26423e2bf2b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_f5aec26423e2bf2b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_f7d65a3c6b4deb6d` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fb2dac7ac0d17108` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fb2dac7ac0d17108` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_fb2dac7ac0d17108` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_fc344ad5edc4b52f` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_0974fadcf02fc3bc`: imports_symbol; symbol: get_load_dotenv
- `chunk_fc344ad5edc4b52f` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_fc344ad5edc4b52f` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_fc344ad5edc4b52f` → `chunk_2c910577b76376cf`: imports_symbol; symbol: Environment
- `chunk_fc344ad5edc4b52f` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_344cc17acd65dd58`: imports_symbol; symbol: _CollectErrors
- `chunk_fc344ad5edc4b52f` → `chunk_36957f18a0a76b79`: imports_symbol; symbol: get_flashed_messages
- `chunk_fc344ad5edc4b52f` → `chunk_3c8a6bfae0776ce3`: imports_symbol; symbol: SecureCookieSessionInterface
- `chunk_fc344ad5edc4b52f` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_fc344ad5edc4b52f` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_fc344ad5edc4b52f` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_a6940afbd6f42ea7`: imports_symbol; symbol: AppContext
- `chunk_fc344ad5edc4b52f` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_fc344ad5edc4b52f` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_dd100daace83e5ce`: imports_symbol; symbol: App
- `chunk_fc344ad5edc4b52f` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_fc344ad5edc4b52f` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_fc5a015e48f7d783` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_8b04179a9854c150`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_fcf9f39569fef058` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_fcf9f39569fef058` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fcf9f39569fef058` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **NO_REPORTABLE_FINDINGS**

No reportable risk findings. This does not mean the repository is risk-free.
